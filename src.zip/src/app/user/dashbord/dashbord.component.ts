import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { AppService } from 'src/app/app.service';
import { User } from 'src/app/signup/signup.component';


// export interface UserData {
//   city: string,
//   contactNo: string,
//   email: string,
//   gender: string,
//   password: string,
//   pincode: string,
//   state: string,
//   username: string,
//   image:string,
//   status:string,
//   dob:string
// }

@Component({
  selector: 'app-dashbord',
  templateUrl: './dashbord.component.html',
  styleUrls: ['./dashbord.component.css']
})
export class DashbordComponent {

user = {
  city: "Muzaffarnagar",
  contactNo: "6395215948",
  email: "abhijeetbaliyan@gmail.com",
  dob: "01/04/1998",
  gender: "Male",
  password: "123213",
  pincode: 251306,
  state: "UP",
  username: "Abhijeet Baliyan",
  image:"xyz",
  status:"save plants"
}

// userlist : User[] | undefined;

// constructor(private appService:AppService,private tost:ToastrService){
//   this.appService.getUnKnownUsers().subscribe(
//     (responce) =>{
//       this.userlist = responce;
//       console.log(this.userlist);
//     },(error)=>{
//       console.log(error);
//       this.tost.error(error);
//     }
//   );
// }





}
