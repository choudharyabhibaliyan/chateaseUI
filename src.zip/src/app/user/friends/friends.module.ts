import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FriendsComponent } from './friends.component';
import { RouterModule, Routes } from '@angular/router';
import { AddfrendComponent } from './addfrend/addfrend.component';
import { SendRequestComponent } from './send-request/send-request.component';

const route: Routes = [ 
  {path:'',component:FriendsComponent},
  {path:'addFriends' , component:AddfrendComponent},
  {path:'sentRequests',component:SendRequestComponent}
];


@NgModule({
  declarations: [
    FriendsComponent,
    AddfrendComponent,
    SendRequestComponent
  ],
  imports: [
    CommonModule,RouterModule.forChild(route)
  ],
  exports: [RouterModule],
  bootstrap: [FriendsComponent]
})
export class FriendsModule { }
