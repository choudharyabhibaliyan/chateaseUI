import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { UserComponent } from './user.component';
import { FormsModule } from '@angular/forms';
import { NotificationComponent } from './notification/notification.component';
import { DashbordComponent } from './dashbord/dashbord.component';
import { ChatComponent } from './chat/chat.component';
import { PostComponent } from './post/post.component';
import { SettingsComponent } from './settings/settings.component';
import { FriendsModule } from './friends/friends.module';
const route: Routes = [
  {
    path:'user',component: UserComponent,children: [
      { path:'notification',component:NotificationComponent },
      { path:'sms',         component:ChatComponent },
      { path:'friends',     loadChildren: () => import('./friends/friends.module').then(m => m.FriendsModule) },
      { path:'dashbord',    component:DashbordComponent },
      { path:'setting',     component:SettingsComponent }
    ]
  }
];

@NgModule({
  declarations: [
    UserComponent,
    NotificationComponent,
    DashbordComponent,
    ChatComponent,
    PostComponent,
    SettingsComponent
  ],
  imports: [
    RouterModule.forChild(route),
    CommonModule,
    FormsModule,
    FriendsModule
  ],
  exports: [
  ],
  bootstrap: []
})
export class UserModule { }
