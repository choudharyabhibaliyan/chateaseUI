import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AppService } from './app.service';
import { WebSocketAPI } from './WebSockitAPI';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit{
  userLogout: string = 'Logout';
  // webSocketAPI: WebSocketAPI;
  // greeting: any;
  // name: string;
  
  public isLogin=localStorage.getItem("isLogin");
  constructor(private router:Router,private appService:AppService){
  
  }

  ngOnInit(): void {
    // this.webSocketAPI = new WebSocketAPI(new AppComponent());
     this.appService.userLogout.subscribe(v=>{
      console.log(v)
      this.userLogout=v;
     })
  }


  logout(){
    console.log("logout")
    localStorage.removeItem('isLogin');
    this.appService.userLogout.next('');
    this.userLogout='';
    this.router.navigateByUrl("/login")
  }

  



  // connect(){
  //   this.webSocketAPI._connect();
  // }

  // disconnect(){
  //   this.webSocketAPI._disconnect();
  // }

  // sendMessage(){
  //   this.webSocketAPI._send(this.name);
  // }

  // handleMessage(message){
  //   this.greeting = message;
  // }
}
