import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from './signup/signup.component';

@Injectable({
  providedIn: 'root'
})
export class AppService {
  public baseURL = 'http://localhost:7000';
  httpHeader = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Authorization': 'Bearer ' + localStorage.getItem("token")
    })
  };

  public userLogout = new Subject<string>();
  constructor(private http: HttpClient) { }

  login(cred:any) :any {
    return this.http.post<any>(`${this.baseURL}/token`,cred);
  }

  regester(user: any) {
    return this.http.post<any>(`${this.baseURL}/register`,user);
  }

  getUnKnownUsers() {
    console.log(this.httpHeader.headers.getAll);
    return this.http.get<any>(`${this.baseURL}/findUnknownUsers/18`,this.httpHeader);
  }

  sendFriendRequest(id:number):any {
    return this.http.put(`${this.baseURL}/sendFriendRequest/18/${id}` ,this.httpHeader);
  }

}
